package ZadaniaLaby4;

public class ZadaniaLab4 {
    protected  void zad1(){}
    protected  void zad2(){}
    protected  void zad3(){}
    protected  void zad4(){}
    protected  void zad5(){}
    protected  void zad6(){}
    protected  void zad7(){}
}
