package ZadaniaLaby2;
import java.util.Scanner;

public class RunTuskslaby2 {
    public static void RunTusklaby2() {
        Scanner scan = new Scanner(System.in);// funkcja "scanf"
        int nr;
        do {
            System.out.println("Podaj numer zadania od 1 do  :");


            while (!scan.hasNextInt()) { //warunek sprawdzajacy poprawnosc podanych danych w tym przypadku czy sa to inty
                System.out.println("Wymagana liczba całkowita od 1 do , spróbuj ponownie.");
                scan.next();
            }

            nr = scan.nextInt();
            if (nr < 1 || nr >5 ) {
                System.out.println("Nie ma takiego zadania sproboj ponownie");
            }

        } while (nr < 1 || nr >5 );

       switch (nr) {
            case 1:
                System.out.println("1.Zadanie:");
                Zadania task1 = new Zadania(); //nazwa klasy
                task1.zad1(); // nazwa funkcji w klasie
                break;
            case 2:
                System.out.println("2.Zadanie: ");
                Zadania task2 = new Zadania();
                task2.zad2();
                break;
           case 3:
                System.out.println("3.Zadanie:");
                Zadania task3 = new Zadania();
                task3.zad3());
                break;
           /* case 4:
                System.out.println("4.Zadanie:");
                zad4 task4 = new zad4();
                System.out.println(task4.podz5());
                break;
            case 5:
                System.out.println("5.Zadanie:");
                zad5 task5 = new zad5();
                task5.potega();
                break;*/
            default:
                System.out.println("Nieoczekiwany błąd.");
                break;

        }
        scan.close();


    }

}